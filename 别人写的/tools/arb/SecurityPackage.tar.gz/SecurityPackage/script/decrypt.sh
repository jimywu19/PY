#!/bin/bash

getCurPath()
{
    cd $(dirname $0)
    g_curPath="$PWD"
    g_scriptName="$(basename $0)"
    cd - >/dev/null
}

##############################################################
## @Param show the EEOR infos.
## @Usage showErr msg
## @Return null
## @Description error show as red
##############################################################
showErr()
{
    echo -e "\033[31mERROR: ${1}\033[0m"
}

##############################################################
## @Param no paras
## @Usage InputPasswd
## @Return 0:succ others:failed
## @Description get new passwd
##############################################################
function getClassPath()
{
    local LIBS="$1"
    local LIBS_PATH="$2"
    classList=
    if [ "$LIBS_PATH" = "" ]
    then
        return 1
    fi

    if [ -z "$LIBS" ];then
        return 1
    fi

    libsList=`echo $LIBS | sed 's/ /\*/g' | sed 's/;/ /g'`
    for libFile in  $libsList
    do
        fileName=`ls "$LIBS_PATH/$libFile"*`
        classList=$classList:$fileName
    done
    CLASSPATH=`echo ${classList:1}`
}


InputPasswd()
{
    while [ 0 ];
    do
        echo -e "Input Password:\c "
        PASSWD=""
        read -a PASSWD -s
        echo " "

        echo -e "Input Password again:\c "
        PASSWD_AGINE=""
        read -a PASSWD_AGINE -s
        echo " ";

        if [ "${PASSWD}" == "${PASSWD_AGINE}" ]; then
            break
        else
            showErr "two Password is different, input again..."
            continue
        fi
   done

   return 0
}

##########################################################################################
#   FUNCTION   : getPara
#   DESCRIPTION: get input paramters
#   CALLED BY  :
#   INPUT      : -e: need enc string
#                -d: need dec string
###########################################################################################
getPara()
{
    if [ $# -eq 1 ] && [ $1 == "-s" ]; then
        InputPasswd
        return 0
    elif [ $# -ne 2 ]; then
        showErr "parameter invalid"
        return 1
    fi

    if [ "$1" == "-e" ]; then
        g_pass=$2
    fi

    if [ "$1" == "-d" ]; then
        g_encPass=$2
    fi  
    return 0
}


##############################################################
## @Usage checkEnv
## @Return 0:succ; othe:failed
## @Description check currrent enviroment healthy?
##############################################################
checkEnv()
{
    local CURRENT_USER=$(whoami);

    #01. is right user?
    if [ ${CURRENT_USER} != "root" ];then
       showErr "illegal user!!!"
       return 1;
    fi

    g_java=$(which java) 
    if [ -z "$g_java" ]; then
       showErr "illegal enviroment!!!"
       return 1;
    fi

    #03. is JRE can be used?
    $g_java -version > /dev/null 2>&1 
    if [ $? -ne 0 ]; then
       showErr "illegal enviroment!!!"
       return 1;
    fi

    return 0
}


##############################################################
## @Usage encDecStr
## @Return 0:succ; othe:failed
## @Description encript or decript the input string
##############################################################
encDecStr()
{
    local libs="encrypt;apache-log4j;commons-codec;commons-lang3;log4j;wcc_common;wcc_crypt;wcc_log"
    getClassPath "$libs" "$g_curPath/../lib/"
    local javaArgs="-Dbeetle.application.home.path=${g_curPath}/../conf"
    local className="com.huawei.ha.encrypt.EncryptDecryptHandler"
    local classNameParam="com.huawei.ha.encrypt.EncryptHandlerWithoutParam"
    local java_cmd="${g_java} -cp ${CLASSPATH} ${javaArgs} ${className}"
    local java_cmd_param="${g_java} -cp ${CLASSPATH} ${javaArgs} ${classNameParam}"

    local result=""
    if [ -n "$g_pass" ]; then
        result=$(${java_cmd} -e "${g_pass}") 
    fi

    if [ -n "$g_encPass" ]; then
        result=$(${java_cmd} -d "${g_encPass}")
    fi

    if [ -n "$PASSWD" ]; then
        result=`${java_cmd_param}  <<EOF
-s
$PASSWD
EOF`
    fi

    if [[ "$result" =~ "ERROR" ]]; then
        showErr "encrypt error: $result"
        return 1
    fi

    if [[ "$result" =~ "Exception" ]]; then
        showErr "encrypt Exception: $result"
        return 1
    fi

    if [ -z "$result" ]; then
        showErr "encrypt result is null!"
        return 1
    fi

    echo "$result"

    return 0
}

##############################################################
## @Usage main "$@"
## @Return 0:succ; othe:failed
## @Description the shell main function
##############################################################
main()
{
    checkEnv || { return 1; }

    getPara "$@" || { return 1; }

    encDecStr   || { return 1; }

    return 0
}

######################################## START ########################################
getCurPath || { showErr "getCurPath failed!!!" ; exit 1; }
main "$@"
exit $?
######################################## ENDED ########################################
 
